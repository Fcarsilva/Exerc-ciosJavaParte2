package Exercicios;

public class Funcionario {
    public static void main(String[] args) {

    }

}
