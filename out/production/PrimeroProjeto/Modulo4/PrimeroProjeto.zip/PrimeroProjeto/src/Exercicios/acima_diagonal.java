package Exercicios;

public class acima_diagonal {


}
