package Exercicios;

import com.sun.source.util.SimpleTreeVisitor;
import entitie.ImportedProduct;
import entitie.Product;
import entitie.Products;
import entitie.UsedProduct;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ProgramaProduto {

    public static void main(String[] args) throws ParseException {

        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        List<Products> list = new ArrayList<>();

        System.out.println("Enter the number of products");
        int n = sc.nextInt();

        for (int i=1; i<=n; i++){
            System.out.println("Product #" + i +" data:");
            System.out.print("Common, used or imported (c/u/i)?");
            char type = sc.next().charAt(0);

            System.out.print("Name:");
            sc.nextLine();
            String name = sc.nextLine();
            System.out.print("Price:");
            double price = sc.nextDouble();
            if (type == 'c'){
                list.add(new Products(name, price));
            }
            else if (type == 'u'){
                System.out.print("Manufacture date (DD/MM/YYYY):");
                Date date = sdf.parse(sc.next());
                list.add(new UsedProduct(name, price, date));
            }
            else {
                System.out.println("Customs fee:");
                double customsFee = sc.nextDouble();
                list.add(new ImportedProduct(name, price, customsFee));
            }

            }

            System.out.println();
            System.out.println("Price tags");
            for (Products prod: list){
                System.out.println(prod.priceTag());
            }
            sc.close();

        }
    }


